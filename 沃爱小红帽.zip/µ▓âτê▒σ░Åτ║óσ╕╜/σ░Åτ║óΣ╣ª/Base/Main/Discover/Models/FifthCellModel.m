//
//  FifthCellModel.m
//  SmallBook
//
//  Created by Apple on 16/2/23.
//  Copyright © 2016年 胡哲逊. All rights reserved.
//

#import "FifthCellModel.h"

@implementation FifthCellModel

@end
