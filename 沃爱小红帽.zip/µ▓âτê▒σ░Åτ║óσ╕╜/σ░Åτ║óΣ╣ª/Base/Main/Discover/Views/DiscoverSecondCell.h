//
//  DiscoverSecondCell.h
//  SmallBook
//
//  Created by Macx on 16/2/24.
//  Copyright © 2016年 胡哲逊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverSecondCell : UITableViewCell

@property(nonatomic, copy)NSMutableArray *modalArr;

@end
